\# PermBot — Terms of Service

\*\*Effective Date:\*\* September 2026



By inviting \*\*PermBot\*\* ("the bot", "we", "us") to your Discord server, interacting with its commands, or clicking any of its interactive buttons and menus, you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, you must remove the bot from your server immediately.



\---



\### 1. Eligibility \& Discord Terms

\* You must be at least 13 years old (or the minimum legal age in your country) to use PermBot.

\* All users must comply with \[Discord's Terms of Service](https://discord.com/terms) and \[Community Guidelines](https://discord.com/guidelines). Any activity that violates Discord's platform rules is strictly prohibited on PermBot.

\* Server administrators and owners are responsible for how PermBot is configured and used within their respective communities.



\---



\### 2. Services \& Features Provided

PermBot is a multipurpose Discord utility providing:

\* \*\*Hi-Fi Music \& Audio:\*\* Local audio streaming, equalizer DSP filters, seek controls, and public lyrics lookups.

\* \*\*Server Moderation \& Security:\*\* Warnings, timeouts, kicks, bans, purge tools, anti-spam, anti-mass-mention, anti-invite filters, and automated Anti-Raid lockdown shields.

\* \*\*Community Tools:\*\* Apollo-style event scheduling with waitlists, interactive button polls with live results, QR code generation, and incognito self-role panels.

\* \*\*Voice \& Support Systems:\*\* Join-to-create temporary voice channels and support ticket handling with modal forms and transcript generation.

\* \*\*User Customization:\*\* Custom playlist creation, favorite tracks storage, and profile/server info analytics.

\* \*\*Server Backups:\*\* Automated disaster-recovery archiving of bot configuration files.



We reserve the right to update, modify, or temporarily suspend any feature to maintain bot stability or adapt to Discord platform changes.



\---



\### 3. Acceptable Use Policy

When interacting with PermBot, you agree \*\*NOT\*\* to:

\* Attempt to bypass command cooldowns, flood the bot with automated requests, or intentionally exploit software bugs to crash or lag the bot.

\* Use the bot's features (such as polls, custom playlists, QR codes, or tickets) to distribute malware, phishing links, illegal material, or hate speech.

\* Attempt to access, tamper with, or manipulate data belonging to other Discord servers or users.

\* Abuse the Anti-Raid or moderation commands to maliciously lock down or disrupt servers without authorization.



Violation of these rules may result in your User ID or your entire Discord server being permanently blacklisted from using PermBot.



\---



\### 4. Audio, Lyrics \& Third-Party Content

\* PermBot streams audio and retrieves lyrics based on queries submitted by server members.

\* PermBot does not host or claim ownership of any copyright-protected media streamed or displayed.

\* Users are solely responsible for the audio content, links, and text queries they submit to voice channels and chat.



\---



\### 5. Disclaimer of Warranties \& Limitation of Liability

\* PermBot is provided on an \*\*"as-is" and "as-available"\*\* basis without warranties of any kind, either express or implied.

\* We make reasonable efforts to maintain high uptime, but we do not guarantee that the bot will operate uninterrupted, bug-free, or without latency.

\* \*\*No Liability:\*\* The bot creators and maintainers are not liable for:

&#x20; \* Any server data loss, misconfigured permissions, or unintended moderation actions (such as automated kicks or timeouts) executed by server administrators.

&#x20; \* Missed event notifications or external calendar synchronization delays.

&#x20; \* Content posted by third parties via ticket transcripts, polls, or QR codes.



\---



\### 6. Termination of Service

\* You may terminate your use of PermBot at any time by kicking or banning the bot from your server.

\* We reserve the right to terminate access, revoke command permissions, or blacklist any user or server found violating these Terms or Discord's Developer Policies without prior notice.



\---



\### 7. Changes to Terms

We may update these terms from time to time. Any revisions will be indicated by the "Effective Date" at the top. Continued use of PermBot after updates are posted constitutes acceptance of the modified Terms.



\---



\### Contact \& Support

If you have questions about these Terms of Service or need assistance, please contact the bot owner directly via Discord.


import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timezone, timedelta
import uuid

from utils.helpers import load_json, save_json, generate_gcal_link, parse_dt_flexible

EVENTS_FILE = "data/events.json"

class EventRSVPView(discord.ui.View):
    def __init__(self, event_id: str):
        super().__init__(timeout=None)
        self.event_id = event_id

    async def handle_rsvp(self, interaction: discord.Interaction, status: str):
        data = await load_json(EVENTS_FILE, {"events": {}})
        events = data.get("events", {})
        if self.event_id not in events:
            return await interaction.response.send_message("❌ This event no longer exists.", ephemeral=True)

        event = events[self.event_id]
        user_id = str(interaction.user.id)

        for st in ["going", "maybe", "declined"]:
            if user_id in event.get(st, []):
                event[st].remove(user_id)

        event.setdefault(status, []).append(user_id)
        await save_json(EVENTS_FILE, data)

        # Update embed
        embed = interaction.message.embeds[0]
        for i, field in enumerate(embed.fields):
            if field.name.startswith("✅ Going"):
                embed.set_field_at(i, name=f"✅ Going ({len(event.get('going', []))})", value=", ".join(f"<@{u}>" for u in event.get('going', [])) or "None", inline=True)
            elif field.name.startswith("❔ Maybe"):
                embed.set_field_at(i, name=f"❔ Maybe ({len(event.get('maybe', []))})", value=", ".join(f"<@{u}>" for u in event.get('maybe', [])) or "None", inline=True)
            elif field.name.startswith("❌ Declined"):
                embed.set_field_at(i, name=f"❌ Declined ({len(event.get('declined', []))})", value=", ".join(f"<@{u}>" for u in event.get('declined', [])) or "None", inline=True)

        await interaction.response.edit_message(embed=embed, view=self)

    @discord.ui.button(label="Going", style=discord.ButtonStyle.success, custom_id="rsvp_going", emoji="✅")
    async def going_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_rsvp(interaction, "going")

    @discord.ui.button(label="Maybe", style=discord.ButtonStyle.secondary, custom_id="rsvp_maybe", emoji="❔")
    async def maybe_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_rsvp(interaction, "maybe")

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.danger, custom_id="rsvp_decline", emoji="❌")
    async def decline_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.handle_rsvp(interaction, "declined")

class EventDetailsModal(discord.ui.Modal, title="Create Server Event"):
    title_input = discord.ui.TextInput(label="Event Title", placeholder="Clan Raid / Game Night", max_length=100, required=True)
    desc_input = discord.ui.TextInput(label="Description", style=discord.TextStyle.paragraph, placeholder="Details about the event...", max_length=1000, required=False)
    start_time_input = discord.ui.TextInput(label="Start Time (YYYY-MM-DD HH:MM in UTC)", placeholder="2026-09-17 18:00", max_length=30, required=True)
    duration_input = discord.ui.TextInput(label="Duration in Hours", placeholder="2", default="1", max_length=5, required=False)

    async def on_submit(self, interaction: discord.Interaction):
        raw_time = self.start_time_input.value.strip()
        try:
            start_dt = parse_dt_flexible(raw_time)
        except Exception:
            return await interaction.response.send_message("❌ Invalid date format. Please use `YYYY-MM-DD HH:MM` (e.g. `2026-09-17 18:00`).", ephemeral=True)

        try:
            duration_hours = float(self.duration_input.value.strip() or "1")
        except ValueError:
            duration_hours = 1.0

        end_dt = start_dt + timedelta(hours=max(0.25, duration_hours))
        event_id = str(uuid.uuid4())[:8]
        title = self.title_input.value.strip()
        desc = self.desc_input.value.strip() or "No description provided."

        gcal_url = generate_gcal_link(title, desc, start_dt, end_dt)

        data = await load_json(EVENTS_FILE, {"events": {}})
        data.setdefault("events", {})[event_id] = {
            "id": event_id,
            "guild_id": interaction.guild_id,
            "creator_id": interaction.user.id,
            "title": title,
            "description": desc,
            "start_iso": start_dt.isoformat(),
            "end_iso": end_dt.isoformat(),
            "going": [str(interaction.user.id)],
            "maybe": [],
            "declined": []
        }
        await save_json(EVENTS_FILE, data)

        ts = int(start_dt.timestamp())
        embed = discord.Embed(title=f"📅 {title}", description=desc, color=0x3498db)
        embed.add_field(name="⏰ Start Time", value=f"<t:{ts}:F> (<t:{ts}:R>)", inline=False)
        embed.add_field(name="⏳ Duration", value=f"{duration_hours} hour(s)", inline=False)
        embed.add_field(name="✅ Going (1)", value=f"<@{interaction.user.id}>", inline=True)
        embed.add_field(name="❔ Maybe (0)", value="None", inline=True)
        embed.add_field(name="❌ Declined (0)", value="None", inline=True)
        embed.add_field(name="🔗 Add to Calendar", value=f"[Google Calendar Link]({gcal_url})", inline=False)
        embed.set_footer(text=f"Event ID: {event_id} • Created by {interaction.user.display_name}")

        view = EventRSVPView(event_id=event_id)
        await interaction.response.send_message(embed=embed, view=view)

class EventsCog(commands.Cog, name="Events"):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        data = await load_json(EVENTS_FILE, {"events": {}})
        for event_id in data.get("events", {}):
            self.bot.add_view(EventRSVPView(event_id))

    @commands.hybrid_group(name="event", description="Manage server events.", fallback="help")
    @commands.guild_only()
    async def event_group(self, ctx: commands.Context):
        embed = discord.Embed(title="📅 Event Commands", color=0x3498db)
        embed.add_field(name="`!event create` / `/event create`", value="Opens the event creation modal.", inline=False)
        embed.add_field(name="`!event list` / `/event list`", value="Lists all upcoming server events.", inline=False)
        embed.add_field(name="`!event delete <id>` / `/event delete <id>`", value="Deletes a scheduled event.", inline=False)
        await ctx.reply(embed=embed, ephemeral=True)

    @event_group.command(name="create", description="Create a new scheduled server event.")
    @commands.guild_only()
    async def event_create(self, ctx: commands.Context):
        if ctx.interaction:
            await ctx.interaction.response.send_modal(EventDetailsModal())
        else:
            # In prefix mode, provide a button to pop the modal (Discord API requirement for modals)
            view = discord.ui.View()
            btn = discord.ui.Button(label="Open Event Form", style=discord.ButtonStyle.primary, emoji="📝")
            
            async def btn_callback(interaction: discord.Interaction):
                if interaction.user.id != ctx.author.id:
                    return await interaction.response.send_message("❌ This button is not for you.", ephemeral=True)
                await interaction.response.send_modal(EventDetailsModal())
                
            btn.callback = btn_callback
            view.add_item(btn)
            await ctx.reply("Click below to open the event creation form:", view=view)

    @event_group.command(name="list", description="List all scheduled server events.")
    @commands.guild_only()
    async def event_list(self, ctx: commands.Context):
        data = await load_json(EVENTS_FILE, {"events": {}})
        events = data.get("events", {})
        guild_events = [e for e in events.values() if e.get("guild_id") == ctx.guild.id]

        if not guild_events:
            return await ctx.reply("📅 No events are currently scheduled.", ephemeral=True)

        embed = discord.Embed(title=f"📅 Upcoming Events ({len(guild_events)})", color=0x3498db)
        for ev in guild_events[:10]:
            st = parse_dt_flexible(ev.get("start_iso"))
            ts = int(st.timestamp())
            going_cnt = len(ev.get("going", []))
            embed.add_field(
                name=f"{ev['title']} (ID: `{ev['id']}`)",
                value=f"⏰ <t:{ts}:F> (<t:{ts}:R>)\n👥 **Going:** {going_cnt}\n📝 {ev['description'][:100]}",
                inline=False
            )
        await ctx.reply(embed=embed)

    @event_group.command(name="delete", description="Delete a scheduled event by ID.")
    @commands.guild_only()
    async def event_delete(self, ctx: commands.Context, event_id: str):
        data = await load_json(EVENTS_FILE, {"events": {}})
        events = data.get("events", {})
        if event_id not in events:
            return await ctx.reply(f"❌ No event found with ID `{event_id}`.", ephemeral=True)

        ev = events[event_id]
        is_creator = ev.get("creator_id") == ctx.author.id
        is_admin = ctx.author.guild_permissions.administrator

        if not (is_creator or is_admin):
            return await ctx.reply("❌ You can only delete events you created unless you are an Administrator.", ephemeral=True)

        del events[event_id]
        await save_json(EVENTS_FILE, data)
        await ctx.reply(f"✅ Successfully deleted event `{event_id}`.")

async def setup(bot: commands.Bot):
    await bot.add_cog(EventsCog(bot))

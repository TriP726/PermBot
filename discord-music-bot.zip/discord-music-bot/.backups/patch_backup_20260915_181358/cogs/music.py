"""
cogs/music.py - PermBot Music Playback & Audio Management
High-Resolution Stream Processing & Sticky Interactive Player Dashboard
"""

import os
import asyncio
import yt_dlp
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional

from utils.audio import create_audio_source, EQ_PRESETS, EQ_DESCRIPTIONS
from cogs.player_state import Song, GuildPlayer, PlayerView, get_guild_player, guild_players

YTDL_OPTIONS = {
    "format": "bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio/best",
    "extractaudio": True,
    "audioformat": "mp3",
    "outtmpl": "%(extractor)s-%(id)s-%(title)s.%(ext)s",
    "restrictfilenames": True,
    "noplaylist": True,
    "nocheckcertificate": True,
    "ignoreerrors": False,
    "logtostderr": False,
    "quiet": True,
    "no_warnings": True,
    "default_search": "ytsearch",
    "source_address": "0.0.0.0",
}

ytdl = yt_dlp.YoutubeDL(YTDL_OPTIONS)


class Music(commands.Cog):
    """Audiophile music streaming and sticky UI player dashboard."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    def format_time(self, seconds: int) -> str:
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        return f"{h:d}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"

    def generate_progress_bar(self, position: float, duration: int, length: int = 15) -> str:
        if duration <= 0:
            return "🔘" + "▬" * (length - 1) + " (Live)"
        progress = min(1.0, max(0.0, position / duration))
        filled = int(progress * length)
        bar = ""
        for i in range(length):
            if i == filled:
                bar += "🔘"
            elif i < filled:
                bar += "▬"
            else:
                bar += "─"
        return bar

    async def update_dashboard(self, guild: discord.Guild):
        """Renders and posts or updates the sticky 4-row audio dashboard."""
        player = get_guild_player(self.bot, guild.id)
        if not player.text_channel:
            return

        vc = guild.voice_client
        embed = discord.Embed(color=0x2B2D31)

        if player.current:
            pos = player.get_position()
            dur = player.current.duration
            bar = self.generate_progress_bar(pos, dur, length=14)
            pos_str = self.format_time(int(pos))
            dur_str = self.format_time(dur) if dur > 0 else "Live Stream"

            status_emoji = "⏸️ Paused" if player.paused else "▶️ Playing"
            loop_str = f"🔂 {player.loop_mode.title()}" if player.loop_mode != "off" else "➡️ Off"
            vol_pct = int(player.volume * 100)

            embed.title = f"{status_emoji}: {player.current.title}"
            embed.url = player.current.webpage_url
            embed.description = f"`{bar}`\n`[{pos_str} / {dur_str}]`"

            embed.add_field(name="Artist / Channel", value=f"`{player.current.artist}`", inline=True)
            embed.add_field(name="Requested By", value=f"{player.current.requester.mention}", inline=True)
            embed.add_field(name="Volume", value=f"`{vol_pct}%`", inline=True)
            embed.add_field(name="Audio Profile / EQ", value=f"`{player.eq_preset.upper()}`", inline=True)
            embed.add_field(name="Loop Mode", value=f"`{loop_str}`", inline=True)
            embed.add_field(name="Queue Length", value=f"`{len(player.queue)} track(s)`", inline=True)

            if player.current.thumbnail:
                embed.set_thumbnail(url=player.current.thumbnail)
        else:
            embed.title = "🎵 PermBot Studio Audio Hub"
            embed.description = "No track currently playing.\nUse `!play <song>` or `/play` to stream high-resolution music!"
            embed.add_field(name="Default Profile", value=f"`{player.eq_preset.upper()}`", inline=True)
            embed.add_field(name="Volume", value=f"`{int(player.volume * 100)}%`", inline=True)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url if self.bot.user else None)

        view = PlayerView(self.bot, guild.id) if (player.current and vc and vc.is_connected()) else None

        try:
            if player.dashboard_message:
                await player.dashboard_message.edit(embed=embed, view=view)
            else:
                player.dashboard_message = await player.text_channel.send(embed=embed, view=view)
        except Exception:
            try:
                player.dashboard_message = await player.text_channel.send(embed=embed, view=view)
            except Exception:
                pass

    async def play_next(self, guild: discord.Guild):
        player = get_guild_player(self.bot, guild.id)
        vc = guild.voice_client

        if not vc or not vc.is_connected():
            player.current = None
            return

        if not player.skip_requested and player.current:
            if player.loop_mode == "song":
                player.queue.insert(0, player.current)
            elif player.loop_mode == "queue":
                player.queue.append(player.current)

        player.skip_requested = False

        if not player.queue:
            player.current = None
            await self.update_dashboard(guild)
            return

        player.current = player.queue.pop(0)
        target_audio = player.current.local_path if player.current.is_local else player.current.url

        try:
            source = create_audio_source(
                target_audio,
                is_local=player.current.is_local,
                eq_preset=player.eq_preset,
                volume=player.volume,
                seek_seconds=0
            )
            player.reset_track_timing(offset=0)
            vc.play(source, after=lambda e: self.bot.loop.create_task(self.play_next(guild)))
            await self.update_dashboard(guild)
        except Exception as err:
            print(f"[Audio Engine Error] {err}")
            await asyncio.sleep(1.0)
            await self.play_next(guild)

    @commands.hybrid_command(name="play", description="Play audio from YouTube, Spotify links, or search terms.")
    @app_commands.describe(query="Song title or URL")
    async def play(self, ctx: commands.Context, *, query: str):
        if not ctx.author.voice or not ctx.author.voice.channel:
            return await ctx.reply("❌ You must be inside a voice channel to play music.")

        await ctx.defer()
        target_vc = ctx.author.voice.channel
        vc = ctx.guild.voice_client

        if not vc:
            vc = await target_vc.connect()
        elif vc.channel != target_vc:
            await vc.move_to(target_vc)

        player = get_guild_player(self.bot, ctx.guild.id)
        player.text_channel = ctx.channel

        loop = self.bot.loop or asyncio.get_event_loop()
        try:
            data = await loop.run_in_executor(None, lambda: ytdl.extract_info(query, download=False))
        except Exception as e:
            return await ctx.reply(f"❌ Failed to extract audio: `{e}`")

        if not data:
            return await ctx.reply("❌ No playable audio streams found.")

        if "entries" in data:
            track_data = data["entries"][0]
        else:
            track_data = data

        song = Song(track_data, ctx.author)
        player.queue.append(song)

        if not vc.is_playing() and not vc.is_paused():
            await self.play_next(ctx.guild)
            await ctx.reply(f"🎶 Now playing: **{song.title}**")
        else:
            await self.update_dashboard(ctx.guild)
            await ctx.reply(f"📥 Added to queue: **{song.title}** (Position: `#{len(player.queue)}`)")

    @commands.hybrid_command(name="skip", description="Skip the currently playing track.")
    async def skip(self, ctx: commands.Context):
        player = get_guild_player(self.bot, ctx.guild.id)
        vc = ctx.guild.voice_client
        if not vc or not player.current:
            return await ctx.reply("❌ Nothing is currently playing.")
        player.skip_requested = True
        vc.stop()
        await ctx.reply("⏭️ Skipped track.")

    @commands.hybrid_command(name="stop", description="Stop playback and clear the queue.")
    async def stop(self, ctx: commands.Context):
        player = get_guild_player(self.bot, ctx.guild.id)
        vc = ctx.guild.voice_client
        player.queue.clear()
        player.current = None
        if vc:
            vc.stop()
            await vc.disconnect()
        await self.update_dashboard(ctx.guild)
        await ctx.reply("⏹️ Playback stopped and disconnected.")


async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))

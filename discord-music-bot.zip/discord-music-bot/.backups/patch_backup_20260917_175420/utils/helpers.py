﻿import os
import sys
import json
import time
import logging
import datetime
from typing import Any, Dict, List, Optional
import discord

# =====================================================================
# Logger Setup (No Duplicate Log Lines)
# =====================================================================
class CallableLogger:
    def __init__(self, name: str = "PermBot"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False  # Prevents duplicate console prints

        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                fmt="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)

    def info(self, msg: str): self.logger.info(msg)
    def warning(self, msg: str): self.logger.warning(msg)
    def error(self, msg: str): self.logger.error(msg)
    def critical(self, msg: str): self.logger.critical(msg)
    def debug(self, msg: str): self.logger.debug(msg)
    def __call__(self, msg: str): self.logger.info(msg)

log = CallableLogger("PermBot")


# =====================================================================
# Token Loader
# =====================================================================
def load_token(token_file: str = "bot.token.txt") -> str:
    """Reads the Discord bot token from environment or token file."""
    env_token = os.getenv("DISCORD_BOT_TOKEN")
    if env_token:
        return env_token.strip()

    if os.path.exists(token_file):
        with open(token_file, "r", encoding="utf-8") as f:
            token = f.read().strip()
            if token:
                return token

    log.critical(f"Bot token not found! Please create '{token_file}' with your token.")
    sys.exit(1)


# =====================================================================
# Atomic JSON Persistence (Crash & Power-Loss Safe)
# =====================================================================
def load_json(file_path: str, default: Any = None) -> Any:
    """Loads JSON data safely from file. Returns default if missing or corrupted."""
    if not os.path.exists(file_path):
        if default is not None:
            save_json(file_path, default)
            return default
        return {}

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log.error(f"Failed to decode JSON from '{file_path}': {e}. Returning default.")
        return default if default is not None else {}


def save_json(file_path: str, data: Any) -> bool:
    """
    Atomically saves JSON data using a temporary file swap.
    Guarantees no file corruption or 0-byte wipes if process crashes mid-write.
    """
    dir_name = os.path.dirname(file_path)
    if dir_name:
        os.makedirs(dir_name, exist_ok=True)

    # Unique temporary filename to prevent race conditions
    temp_path = f"{file_path}.{os.getpid()}.{time.time_ns()}.tmp"

    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())  # Force OS write to physical disk

        # Atomic file rename / swap (supported on Windows & POSIX)
        os.replace(temp_path, file_path)
        return True
    except Exception as e:
        log.error(f"Atomic JSON save error for '{file_path}': {e}")
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass
        return False


# =====================================================================
# Formatting & General Helpers
# =====================================================================
def format_duration(seconds: float | int) -> str:
    """Converts seconds into HH:MM:SS or MM:SS format."""
    seconds = int(seconds or 0)
    hrs = seconds // 3600
    mins = (seconds % 3600) // 60
    secs = seconds % 60
    if hrs > 0:
        return f"{hrs:02d}:{mins:02d}:{secs:02d}"
    return f"{mins:02d}:{secs:02d}"


def parse_duration(duration_str: str) -> Optional[int]:
    """Parses duration strings like '10s', '5m', '2h', '1d' into seconds."""
    if not duration_str:
        return None
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    duration_str = duration_str.strip().lower()
    unit = duration_str[-1]
    if unit in units and duration_str[:-1].isdigit():
        return int(duration_str[:-1]) * units[unit]
    if duration_str.isdigit():
        return int(duration_str)
    return None


def create_progress_bar(current: float, total: float, length: int = 20) -> str:
    """Creates a visual progress bar with standard indicators."""
    if total <= 0:
        return "🔘" + "▬" * (length - 1)
    progress = max(0.0, min(1.0, current / total))
    filled = int(round(progress * (length - 1)))
    bar = "▬" * filled + "🔘" + "▬" * (length - 1 - filled)
    return bar


async def delete_after_delay(message: discord.Message, delay: int = 5):
    """Asynchronously deletes a message after a given delay in seconds."""
    try:
        await message.delete(delay=delay)
    except (discord.NotFound, discord.Forbidden):
        pass


def scan_local_tracks(folder_path: str) -> List[str]:
    """Scans a directory recursively for supported audio/video files."""
    valid_exts = (
        ".mp3", ".wav", ".ogg", ".m4a", ".flac",
        ".mp4", ".mov", ".mkv", ".webm", ".avi", ".wmv", ".flv"
    )
    tracks = []
    if not os.path.exists(folder_path):
        return tracks
    for root, _, files in os.walk(folder_path):
        for file in files:
            if file.lower().endswith(valid_exts):
                tracks.append(os.path.join(root, file))
    return tracks


def get_music_folders(music_dir: str = "music") -> List[str]:
    """Returns top-level subfolder names inside the music directory."""
    if not os.path.exists(music_dir):
        os.makedirs(music_dir, exist_ok=True)
        return []
    return [
        d for d in os.listdir(music_dir)
        if os.path.isdir(os.path.join(music_dir, d)) and not d.startswith(".")
    ]


def generate_gcal_link(title: str, start_dt: datetime.datetime, end_dt: datetime.datetime, details: str = "") -> str:
    """Generates a Google Calendar event creation URL."""
    fmt = "%Y%m%dT%H%M%SZ"
    s_utc = start_dt.strftime(fmt)
    e_utc = end_dt.strftime(fmt)
    import urllib.parse
    params = {
        "action": "TEMPLATE",
        "text": title,
        "dates": f"{s_utc}/{e_utc}",
        "details": details
    }
    return f"https://calendar.google.com/calendar/render?{urllib.parse.urlencode(params)}"
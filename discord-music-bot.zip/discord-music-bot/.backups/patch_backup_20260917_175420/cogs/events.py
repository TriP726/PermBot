﻿import os
import json
import asyncio
from datetime import datetime, timezone, timedelta
import discord
from discord.ext import commands, tasks
from typing import Dict, Any, List, Optional
from utils.helpers import log, generate_gcal_link, delete_after_delay

EVENTS_FILE = os.path.join("data", "events.json")

def load_events() -> Dict[str, Any]:
    if not os.path.exists(EVENTS_FILE):
        return {}
    with open(EVENTS_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except Exception:
            return {}

def save_events(data: Dict[str, Any]):
    os.makedirs(os.path.dirname(EVENTS_FILE), exist_ok=True)
    with open(EVENTS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

class EventView(discord.ui.View):
    def __init__(self, event_id: str):
        super().__init__(timeout=None)
        self.event_id = event_id

    @discord.ui.button(label="Accept", emoji="✅", style=discord.ButtonStyle.success, custom_id="event_accept")
    async def accept_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        events = load_events()
        if self.event_id not in events:
            await interaction.response.send_message("❌ Event not found.", ephemeral=True)
            return

        ev = events[self.event_id]
        u_id = str(interaction.user.id)
        ev["tentative"] = [x for x in ev["tentative"] if x != u_id]
        ev["declined"] = [x for x in ev["declined"] if x != u_id]
        ev["waitlist"] = [x for x in ev["waitlist"] if x != u_id]

        max_cap = ev.get("max_attendees", 0)
        if max_cap > 0 and len(ev["accepted"]) >= max_cap and u_id not in ev["accepted"]:
            ev["waitlist"].append(u_id)
            save_events(events)
            pos = len(ev["waitlist"])
            await interaction.response.send_message(f"⏳ Event is full ({max_cap}/{max_cap}). You are placed at **Waitlist Position #{pos}**.", ephemeral=True)
        else:
            if u_id not in ev["accepted"]:
                ev["accepted"].append(u_id)
            save_events(events)
            await interaction.response.send_message("✅ You are confirmed as **Attending**!", ephemeral=True)

        await self.refresh_public_embed(interaction.message, ev)

    @discord.ui.button(label="Tentative", emoji="❓", style=discord.ButtonStyle.secondary, custom_id="event_tentative")
    async def tentative_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        events = load_events()
        if self.event_id not in events:
            await interaction.response.send_message("❌ Event not found.", ephemeral=True)
            return

        ev = events[self.event_id]
        u_id = str(interaction.user.id)
        was_accepted = u_id in ev["accepted"]
        ev["accepted"] = [x for x in ev["accepted"] if x != u_id]
        ev["declined"] = [x for x in ev["declined"] if x != u_id]
        ev["waitlist"] = [x for x in ev["waitlist"] if x != u_id]

        if u_id not in ev["tentative"]:
            ev["tentative"].append(u_id)
        
        if was_accepted and ev["waitlist"]:
            promoted_id = ev["waitlist"].pop(0)
            ev["accepted"].append(promoted_id)
            asyncio.create_task(self.notify_promoted_user(interaction.client, int(promoted_id), ev))

        save_events(events)
        await interaction.response.send_message("❓ RSVP marked as **Tentative**.", ephemeral=True)
        await self.refresh_public_embed(interaction.message, ev)

    @discord.ui.button(label="Decline", emoji="❌", style=discord.ButtonStyle.danger, custom_id="event_decline")
    async def decline_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        events = load_events()
        if self.event_id not in events:
            await interaction.response.send_message("❌ Event not found.", ephemeral=True)
            return

        ev = events[self.event_id]
        u_id = str(interaction.user.id)
        was_accepted = u_id in ev["accepted"]
        ev["accepted"] = [x for x in ev["accepted"] if x != u_id]
        ev["tentative"] = [x for x in ev["tentative"] if x != u_id]
        ev["waitlist"] = [x for x in ev["waitlist"] if x != u_id]

        if u_id not in ev["declined"]:
            ev["declined"].append(u_id)

        if was_accepted and ev["waitlist"]:
            promoted_id = ev["waitlist"].pop(0)
            ev["accepted"].append(promoted_id)
            asyncio.create_task(self.notify_promoted_user(interaction.client, int(promoted_id), ev))

        save_events(events)
        await interaction.response.send_message("❌ RSVP marked as **Declined**.", ephemeral=True)
        await self.refresh_public_embed(interaction.message, ev)

    async def notify_promoted_user(self, client: discord.Client, user_id: int, event_data: Dict[str, Any]):
        try:
            u = await client.fetch_user(user_id)
            if u:
                await u.send(f"🎉 **Great news!** A spot opened up for **{event_data['title']}** and you were promoted from the Waitlist to **Confirmed Attendee**!")
        except Exception:
            pass

    async def refresh_public_embed(self, message: discord.Message, ev: Dict[str, Any]):
        embed = discord.Embed(
            title=f"📅 {ev['title']}",
            description=ev['description'],
            color=discord.Color.teal()
        )
        st_dt = datetime.fromisoformat(ev["start_time"])
        embed.add_field(name="⏰ Time", value=f"<t:{int(st_dt.timestamp())}:F>\n(<t:{int(st_dt.timestamp())}:R>)", inline=False)

        cap_str = f" ({len(ev['accepted'])}/{ev['max_attendees']})" if ev.get("max_attendees", 0) > 0 else f" ({len(ev['accepted'])})"
        acc_names = ", ".join([f"<@{uid}>" for uid in ev['accepted']]) or "*None*"
        embed.add_field(name=f"✅ Confirmed{cap_str}", value=acc_names, inline=False)

        if ev.get("waitlist"):
            wl_names = ", ".join([f"`#{i+1}` <@{uid}>" for i, uid in enumerate(ev['waitlist'])])
            embed.add_field(name=f"⏳ Waitlist ({len(ev['waitlist'])})", value=wl_names, inline=False)

        tent_names = ", ".join([f"<@{uid}>" for uid in ev['tentative']]) or "*None*"
        embed.add_field(name=f"❓ Tentative ({len(ev['tentative'])})", value=tent_names, inline=True)

        if ev.get("gcal_link"):
            embed.add_field(name="🔗 Calendar Sync", value=f"[Add to Google Calendar]({ev['gcal_link']})", inline=False)

        embed.set_footer(text=f"Event ID: {ev['id']} | Created by {ev['creator_name']}")
        await message.edit(embed=embed, view=self)

class EventDetailsModal(discord.ui.Modal, title="Create Scheduled Event"):
    def __init__(self, guild: discord.Guild, channel: discord.TextChannel):
        super().__init__()
        self.guild = guild
        self.channel = channel

        self.title_input = discord.ui.TextInput(label="Event Title", max_length=100, required=True)
        self.desc_input = discord.ui.TextInput(label="Description", style=discord.TextStyle.paragraph, required=True, max_length=500)
        self.time_input = discord.ui.TextInput(label="Start Date/Time (YYYY-MM-DD HH:MM in UTC)", placeholder="2025-05-15 20:00", required=True)
        self.cap_input = discord.ui.TextInput(label="Max Attendees Cap (0 for unlimited)", default="0", required=False)

        self.add_item(self.title_input)
        self.add_item(self.desc_input)
        self.add_item(self.time_input)
        self.add_item(self.cap_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            st = datetime.strptime(self.time_input.value.strip(), "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
        except ValueError:
            await interaction.response.send_message("❌ Invalid date format. Use `YYYY-MM-DD HH:MM` (e.g. `2025-05-15 20:00`).", ephemeral=True)
            return

        try:
            cap = int(self.cap_input.value.strip() or "0")
        except ValueError:
            cap = 0

        event_id = str(int(datetime.now().timestamp()))
        end_dt = st + timedelta(hours=2)
        gcal = generate_gcal_link(self.title_input.value.strip(), self.desc_input.value.strip(), st, end_dt)

        ev_data = {
            "id": event_id,
            "guild_id": self.guild.id,
            "channel_id": self.channel.id,
            "title": self.title_input.value.strip(),
            "description": self.desc_input.value.strip(),
            "start_time": st.isoformat(),
            "max_attendees": cap,
            "creator_name": interaction.user.display_name,
            "accepted": [],
            "tentative": [],
            "declined": [],
            "waitlist": [],
            "gcal_link": gcal,
            "reminded": False
        }

        events = load_events()
        events[event_id] = ev_data
        save_events(events)

        embed = discord.Embed(
            title=f"📅 {ev_data['title']}",
            description=ev_data['description'],
            color=discord.Color.teal()
        )
        embed.add_field(name="⏰ Time", value=f"<t:{int(st.timestamp())}:F>\n(<t:{int(st.timestamp())}:R>)", inline=False)
        embed.add_field(name="✅ Confirmed", value="*None*", inline=False)
        embed.add_field(name="❓ Tentative", value="*None*", inline=True)
        embed.add_field(name="🔗 Calendar Sync", value=f"[Add to Google Calendar]({gcal})", inline=False)
        embed.set_footer(text=f"Event ID: {event_id} | Created by {ev_data['creator_name']}")

        view = EventView(event_id)
        msg = await self.channel.send(embed=embed, view=view)
        ev_data["message_id"] = msg.id
        events[event_id] = ev_data
        save_events(events)

        await interaction.response.send_message(f"✅ Event published successfully to {self.channel.mention}!", ephemeral=True)

class EventsCog(commands.Cog, name="Events"):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.reminder_task.start()

    def cog_unload(self):
        self.reminder_task.cancel()

    @tasks.loop(minutes=1)
    async def reminder_task(self):
        events = load_events()
        now = datetime.now(timezone.utc)
        changed = False

        for ev_id, ev in list(events.items()):
            try:
                st = datetime.fromisoformat(ev["start_time"])
                if not ev.get("reminded") and (now + timedelta(hours=1)) >= st > now:
                    ev["reminded"] = True
                    changed = True
                    for uid in ev.get("accepted", []):
                        try:
                            user = await self.bot.fetch_user(int(uid))
                            if user:
                                await user.send(f"⏰ **Event Reminder:** **{ev['title']}** starts in 1 hour (<t:{int(st.timestamp())}:R>)!")
                        except Exception:
                            pass
            except Exception as e:
                log.error(f"Reminder check error: {e}")

        if changed:
            save_events(events)

    @reminder_task.before_loop
    async def before_reminders(self):
        await self.bot.wait_until_ready()

    @commands.command(name="event")
    @commands.has_permissions(administrator=True)
    async def create_event(self, ctx: commands.Context, channel: Optional[discord.TextChannel] = None):
        try:
            await ctx.message.delete()
        except Exception:
            pass

        target_ch = channel or ctx.channel
        try:
            class OpenModalView(discord.ui.View):
                def __init__(self, guild, ch):
                    super().__init__(timeout=180)
                    self.guild = guild
                    self.ch = ch

                @discord.ui.button(label="📝 Open Event Creator Form", style=discord.ButtonStyle.primary)
                async def open_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
                    modal = EventDetailsModal(self.guild, self.ch)
                    await interaction.response.send_modal(modal)

            view = OpenModalView(ctx.guild, target_ch)
            embed = discord.Embed(
                title=f"📅 Schedule Event for {ctx.guild.name}",
                description=f"Target Channel: {target_ch.mention}\nClick the button below to fill in event details.",
                color=discord.Color.teal()
            )
            await ctx.author.send(embed=embed, view=view)
        except discord.Forbidden:
            pass

    @commands.command(name="events")
    async def list_events(self, ctx: commands.Context):
        events = load_events()
        guild_events = [e for e in events.values() if e.get("guild_id") == ctx.guild.id]

        if not guild_events:
            msg = await ctx.send("📅 No upcoming events scheduled.")
            asyncio.create_task(delete_after_delay(msg, 15))
            return

        embed = discord.Embed(title=f"📅 Scheduled Events - {ctx.guild.name}", color=discord.Color.teal())
        for ev in guild_events[:10]:
            st = datetime.fromisoformat(ev["start_time"])
            embed.add_field(
                name=f"📌 {ev['title']} (ID: `{ev['id']}`)",
                value=f"⏰ <t:{int(st.timestamp())}:F> (<t:{int(st.timestamp())}:R>)\n👥 Attending: `{len(ev.get('accepted', []))}`\n📝 {ev['description'][:100]}",
                inline=False
            )
        msg = await ctx.send(embed=embed)
        asyncio.create_task(delete_after_delay(msg, 45))

    @commands.command(name="myevents")
    async def my_events(self, ctx: commands.Context):
        events = load_events()
        uid = str(ctx.author.id)
        attending = [e for e in events.values() if uid in e.get("accepted", [])]
        waitlisted = [e for e in events.values() if uid in e.get("waitlist", [])]

        if not attending and not waitlisted:
            try:
                await ctx.author.send("📅 You have no active event RSVPs.")
            except Exception:
                pass
            return

        embed = discord.Embed(title="📅 Your Event RSVPs", color=discord.Color.teal())
        if attending:
            desc = "\n".join([f"• **{e['title']}** (<t:{int(datetime.fromisoformat(e['start_time']).timestamp())}:R>)" for e in attending])
            embed.add_field(name="✅ Confirmed Attending", value=desc, inline=False)
        if waitlisted:
            desc = "\n".join([f"• **{e['title']}** (Position #{e['waitlist'].index(uid)+1})" for e in waitlisted])
            embed.add_field(name="⏳ Waitlist", value=desc, inline=False)

        try:
            await ctx.author.send(embed=embed)
        except Exception:
            pass

    @commands.command(name="cancelevent")
    @commands.has_permissions(administrator=True)
    async def cancel_event(self, ctx: commands.Context, event_id: str):
        try:
            await ctx.message.delete()
        except Exception:
            pass
        events = load_events()
        if event_id not in events:
            try:
                await ctx.author.send(f"❌ Event ID `{event_id}` not found.")
            except Exception:
                pass
            return

        ev = events.pop(event_id)
        save_events(events)

        for uid in ev.get("accepted", []) + ev.get("waitlist", []):
            try:
                u = await self.bot.fetch_user(int(uid))
                if u:
                    await u.send(f"📢 The event **{ev['title']}** has been cancelled by server admins.")
            except Exception:
                pass

        try:
            await ctx.author.send(f"✅ Cancelled event **{ev['title']}**.")
        except Exception:
            pass

async def setup(bot: commands.Bot):
    await bot.add_cog(EventsCog(bot))

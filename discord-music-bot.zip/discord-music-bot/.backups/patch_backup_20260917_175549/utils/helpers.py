import os
import json
import asyncio
import urllib.parse
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Any, Union, Optional

_FILE_LOCKS: dict[str, asyncio.Lock] = {}

def _get_lock(filepath: str) -> asyncio.Lock:
    if filepath not in _FILE_LOCKS:
        _FILE_LOCKS[filepath] = asyncio.Lock()
    return _FILE_LOCKS[filepath]

async def load_json(filepath: str, default: Any = None) -> Any:
    lock = _get_lock(filepath)
    async with lock:
        path = Path(filepath)
        if not path.exists():
            return default if default is not None else {}
        try:
            content = await asyncio.to_thread(path.read_text, encoding="utf-8")
            return json.loads(content) if content.strip() else (default if default is not None else {})
        except Exception:
            return default if default is not None else {}

async def save_json(filepath: str, data: Any) -> bool:
    lock = _get_lock(filepath)
    async with lock:
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix(".tmp")
        try:
            serialized = json.dumps(data, indent=2, ensure_ascii=False)
            await asyncio.to_thread(temp_path.write_text, serialized, encoding="utf-8")
            await asyncio.to_thread(os.replace, temp_path, path)
            return True
        except Exception as e:
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except Exception:
                    pass
            raise e

def parse_dt_flexible(dt_val: Union[datetime, str, int, float, None]) -> datetime:
    if dt_val is None:
        return datetime.now(timezone.utc)
    if isinstance(dt_val, datetime):
        return dt_val if dt_val.tzinfo is not None else dt_val.replace(tzinfo=timezone.utc)
    if isinstance(dt_val, (int, float)):
        return datetime.fromtimestamp(dt_val, tz=timezone.utc)
    if isinstance(dt_val, str):
        clean_str = dt_val.strip()
        try:
            dt = datetime.fromisoformat(clean_str)
            return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
        
        formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y/%m/%d %H:%M",
            "%m/%d/%Y %H:%M",
            "%d/%m/%Y %H:%M",
            "%Y-%m-%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
        ]
        for fmt in formats:
            try:
                return datetime.strptime(clean_str, fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
    return datetime.now(timezone.utc)

def generate_gcal_link(title: str, description: str, start_dt: Union[datetime, str, int, float], end_dt: Optional[Union[datetime, str, int, float]] = None) -> str:
    s = parse_dt_flexible(start_dt).astimezone(timezone.utc)
    if end_dt:
        e = parse_dt_flexible(end_dt).astimezone(timezone.utc)
    else:
        e = s + timedelta(hours=1)
        
    fmt = "%Y%m%dT%H%M%SZ"
    dates_param = f"{s.strftime(fmt)}/{e.strftime(fmt)}"
    
    base_url = "https://calendar.google.com/calendar/render?action=TEMPLATE"
    params = {
        "text": title or "Discord Event",
        "details": description or "",
        "dates": dates_param
    }
    return f"{base_url}&{urllib.parse.urlencode(params)}"

def format_seconds(seconds: float) -> str:
    secs = int(max(0, seconds))
    m, s = divmod(secs, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"

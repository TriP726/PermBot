import os
import sys
import re
import json
import asyncio
import logging
import urllib.parse
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Any, Union, Optional

# --- Standard Logging Configuration ---
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
_raw_logger = logging.getLogger("PermBot")

class PermLogger:
    """Hybrid Logger supporting both log.info(...) methods and log('msg') calls."""
    def __init__(self, target_logger: logging.Logger):
        self._logger = target_logger

    def __call__(self, message: str, level: str = "INFO") -> None:
        lvl = getattr(logging, str(level).upper(), logging.INFO)
        self._logger.log(lvl, message)

    def info(self, msg: str, *args, **kwargs) -> None:
        self._logger.info(msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs) -> None:
        self._logger.error(msg, *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs) -> None:
        self._logger.warning(msg, *args, **kwargs)

    def warn(self, msg: str, *args, **kwargs) -> None:
        self._logger.warning(msg, *args, **kwargs)

    def critical(self, msg: str, *args, **kwargs) -> None:
        self._logger.critical(msg, *args, **kwargs)

    def debug(self, msg: str, *args, **kwargs) -> None:
        self._logger.debug(msg, *args, **kwargs)

    def exception(self, msg: str, *args, **kwargs) -> None:
        self._logger.exception(msg, *args, **kwargs)

log = PermLogger(_raw_logger)
logger = _raw_logger

# --- Environment & Token Loading ---
def load_token(key: str = "DISCORD_TOKEN", filepath: str = ".env") -> str:
    token = os.getenv(key)
    if token and token.strip():
        return token.strip()

    env_file = Path(filepath)
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                if k.strip() == key:
                    return v.strip().strip("'").strip('"')

    token_txt = Path("token.txt")
    if token_txt.is_file():
        content = token_txt.read_text(encoding="utf-8").strip()
        if content:
            return content

    return ""

def get_env(key: str, default: Any = None, filepath: str = ".env") -> Any:
    val = os.getenv(key)
    if val is not None:
        return val
    env_file = Path(filepath)
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, v = line.split("=", 1)
                if k.strip() == key:
                    return v.strip().strip("'").strip('"')
    return default

# --- Async UI Helpers ---
async def delete_after_delay(message: Any, delay: float = 5.0) -> None:
    try:
        await asyncio.sleep(delay)
        if hasattr(message, "delete") and callable(message.delete):
            await message.delete()
    except Exception:
        pass

# --- Synchronous Atomic JSON Persistence ---
def load_json(filepath: str, default: Any = None) -> Any:
    path = Path(filepath)
    if not path.exists():
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read().strip()
            return json.loads(content) if content else (default if default is not None else {})
    except Exception:
        return default if default is not None else {}

def save_json(filepath: str, data: Any) -> bool:
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(f".tmp_{os.getpid()}")
    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(temp_path, path)
        return True
    except Exception:
        if temp_path.exists():
            try:
                temp_path.unlink()
            except Exception:
                pass
        return False

# --- Duration Parsing & Subclass ---
class ParsedDuration(timedelta):
    @property
    def seconds_total(self) -> int:
        return int(self.total_seconds())
    def __int__(self) -> int:
        return int(self.total_seconds())
    def __float__(self) -> float:
        return float(self.total_seconds())

def parse_duration(time_str: str) -> Optional[ParsedDuration]:
    if not time_str:
        return None
    clean = str(time_str).strip().lower()
    regex = re.compile(r"(\d+)\s*([smhdw])")
    matches = regex.findall(clean)
    if not matches:
        if clean.isdigit():
            return ParsedDuration(seconds=int(clean))
        return None
    total_seconds = 0
    for val, unit in matches:
        v = int(val)
        if unit == 's': total_seconds += v
        elif unit == 'm': total_seconds += v * 60
        elif unit == 'h': total_seconds += v * 3600
        elif unit == 'd': total_seconds += v * 86400
        elif unit == 'w': total_seconds += v * 604800
    return ParsedDuration(seconds=total_seconds)

# --- UI Progress Bars & Formatting ---
def create_progress_bar(current: float, total: float, length: int = 10, filled_char: str = "█", empty_char: str = "░") -> str:
    if total <= 0:
        return empty_char * length
    progress = max(0.0, min(1.0, current / total))
    filled = int(round(progress * length))
    return filled_char * filled + empty_char * (length - filled)

def format_seconds(seconds: float) -> str:
    secs = int(max(0, seconds))
    m, s = divmod(secs, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"

def format_duration(seconds: float) -> str:
    return format_seconds(seconds)

def humanize_time(seconds: float) -> str:
    return format_seconds(seconds)

def format_bytes(size: Union[int, float]) -> str:
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"

# --- Date-Time & Calendar Helpers ---
def parse_dt_flexible(dt_val: Union[datetime, str, int, float, None]) -> datetime:
    if dt_val is None:
        return datetime.now(timezone.utc)
    if isinstance(dt_val, datetime):
        return dt_val if dt_val.tzinfo is not None else dt_val.replace(tzinfo=timezone.utc)
    if isinstance(dt_val, (int, float)):
        return datetime.fromtimestamp(dt_val, tz=timezone.utc)
    if isinstance(dt_val, str):
        clean_str = dt_val.strip()
        try:
            dt = datetime.fromisoformat(clean_str)
            return dt if dt.tzinfo is not None else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            pass
        
        formats = [
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y/%m/%d %H:%M",
            "%m/%d/%Y %H:%M",
            "%d/%m/%Y %H:%M",
            "%Y-%m-%d",
            "%m/%d/%Y",
            "%d/%m/%Y",
        ]
        for fmt in formats:
            try:
                return datetime.strptime(clean_str, fmt).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
    return datetime.now(timezone.utc)

def generate_gcal_link(title: str, description: str, start_dt: Union[datetime, str, int, float], end_dt: Optional[Union[datetime, str, int, float]] = None) -> str:
    s = parse_dt_flexible(start_dt).astimezone(timezone.utc)
    if end_dt:
        e = parse_dt_flexible(end_dt).astimezone(timezone.utc)
    else:
        e = s + timedelta(hours=1)
        
    fmt = "%Y%m%dT%H%M%SZ"
    dates_param = f"{s.strftime(fmt)}/{e.strftime(fmt)}"
    
    base_url = "https://calendar.google.com/calendar/render?action=TEMPLATE"
    params = {
        "text": title or "Discord Event",
        "details": description or "",
        "dates": dates_param
    }
    return f"{base_url}&{urllib.parse.urlencode(params)}"

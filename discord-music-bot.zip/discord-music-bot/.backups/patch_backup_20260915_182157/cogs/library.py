﻿import os
from typing import Optional
import discord
from discord.ext import commands
from discord import app_commands

from utils.audio import scan_local_library, get_file_metadata, SUPPORTED_MEDIA_EXTENSIONS
from utils.helpers import format_duration

class Library(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.hybrid_command(name="library", description="List music tracks available in the local library.")
    @app_commands.describe(folder="Optional folder to filter by")
    async def library(self, ctx: commands.Context, folder: Optional[str] = None):
        tracks = scan_local_library()
        if not tracks:
            return await ctx.send("📂 Local music library is currently empty.", ephemeral=True)

        if folder:
            tracks = [t for t in tracks if folder.lower() in t["folder"].lower()]
            if not tracks:
                return await ctx.send(f"❌ No tracks found in folder `{folder}`.", ephemeral=True)

        lines = []
        for i, t in enumerate(tracks[:20], 1):
            dur_str = format_duration(t["duration"]) if t["duration"] > 0 else "Unknown"
            lines.append(f"`{i}.` **{t['title']}** (`{t['folder']}`) - `{dur_str}`")

        total_tracks = len(tracks)
        embed = discord.Embed(
            title="📚 Local Music Library",
            description="\n".join(lines),
            color=discord.Color.purple()
        )
        if total_tracks > 20:
            embed.set_footer(text=f"Showing 20 of {total_tracks} tracks. Use /library <folder> or /search <query>.")
        else:
            embed.set_footer(text=f"Total tracks: {total_tracks}")

        await ctx.send(embed=embed)

    @commands.hybrid_command(name="folders", description="List all subfolders in the music directory.")
    async def folders(self, ctx: commands.Context):
        tracks = scan_local_library()
        folder_counts = {}
        for t in tracks:
            f = t["folder"]
            folder_counts[f] = folder_counts.get(f, 0) + 1

        if not folder_counts:
            return await ctx.send("📂 No music folders found.", ephemeral=True)

        lines = [f"📁 **{name}**: `{count}` track(s)" for name, count in folder_counts.items()]
        embed = discord.Embed(
            title="📂 Library Music Folders",
            description="\n".join(lines),
            color=discord.Color.purple()
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="search", description="Search for tracks in the local library.")
    @app_commands.describe(query="Title or folder keyword to search for")
    async def search(self, ctx: commands.Context, query: str):
        tracks = scan_local_library()
        query_lower = query.lower()
        matched = [t for t in tracks if query_lower in t["title"].lower() or query_lower in t["folder"].lower()]

        if not matched:
            return await ctx.send(f"❌ No tracks matched `{query}`.", ephemeral=True)

        lines = []
        for i, t in enumerate(matched[:15], 1):
            dur_str = format_duration(t["duration"]) if t["duration"] > 0 else "Unknown"
            lines.append(f"`{i}.` **{t['title']}** (`{t['folder']}`) - `{dur_str}`")

        embed = discord.Embed(
            title=f"🔍 Search Results for '{query}'",
            description="\n".join(lines),
            color=discord.Color.purple()
        )
        embed.set_footer(text=f"Found {len(matched)} match(es). Use /play <title> to play.")
        await ctx.send(embed=embed)

async def setup(bot: commands.Bot):
    await bot.add_cog(Library(bot))
"""
cogs/library.py - PermBot Local Music Library Management
Commands to scan, list, play, and shuffle all local audio tracks from disk.
"""

import os
import random
import asyncio
import discord
from discord import app_commands
from discord.ext import commands
from typing import List, Optional, Dict, Any

from utils.audio import scan_library, get_local_file_metadata, SUPPORTED_MEDIA_EXTENSIONS
from cogs.player_state import Song, GuildPlayer, get_guild_player

MUSIC_DIRECTORIES = ["music", "songs", "audio", "library", "local_music"]


def get_local_music_files() -> List[Dict[str, Any]]:
    """Scans all standard music directories and returns file metadata."""
    all_files = []
    seen_paths = set()

    for d in MUSIC_DIRECTORIES:
        if os.path.exists(d) and os.path.isdir(d):
            scanned = scan_library(d)
            for item in scanned:
                if item["path"] not in seen_paths:
                    seen_paths.add(item["path"])
                    all_files.append(item)

    return all_files


class Library(commands.Cog):
    """Commands for local music library scanning, browsing, and queueing."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def ensure_voice_connection(self, ctx: commands.Context) -> Optional[discord.VoiceClient]:
        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.reply("❌ You must be inside a voice channel to play music.")
            return None

        target_vc = ctx.author.voice.channel
        vc = ctx.guild.voice_client

        if not vc:
            vc = await target_vc.connect()
        elif vc.channel != target_vc:
            await vc.move_to(target_vc)

        return vc

    @commands.hybrid_command(name="shuffleall", aliases=["shuffle_all", "randomall"], description="Shuffle and play all songs from your local music library.")
    async def shuffleall(self, ctx: commands.Context):
        await ctx.defer()
        vc = await self.ensure_voice_connection(ctx)
        if not vc:
            return

        files = get_local_music_files()
        if not files:
            return await ctx.reply("📁 No local audio files found in `./music`, `./songs`, or `./audio` folders.")

        random.shuffle(files)
        player = get_guild_player(self.bot, ctx.guild.id)
        player.text_channel = ctx.channel

        new_songs = []
        for meta in files:
            song_data = {
                "title": meta.get("title", os.path.splitext(os.path.basename(meta["path"]))[0]),
                "artist": meta.get("artist", "Local Music"),
                "duration": meta.get("duration", 0),
                "url": "",
                "webpage_url": "",
                "thumbnail": None,
                "is_local": True,
                "local_path": meta["path"]
            }
            new_songs.append(Song(song_data, ctx.author))

        player.queue.extend(new_songs)
        music_cog = self.bot.get_cog("Music")

        if not vc.is_playing() and not vc.is_paused():
            if music_cog:
                await music_cog.play_next(ctx.guild)
            await ctx.reply(f"🔀 Shuffled and queued **{len(new_songs)} local tracks** from your library!")
        else:
            if music_cog:
                await music_cog.update_dashboard(ctx.guild)
            await ctx.reply(f"🔀 Added **{len(new_songs)} shuffled local tracks** to the queue!")

    @commands.hybrid_command(name="playall", aliases=["queueall"], description="Queue all local library songs in order.")
    async def playall(self, ctx: commands.Context):
        await ctx.defer()
        vc = await self.ensure_voice_connection(ctx)
        if not vc:
            return

        files = get_local_music_files()
        if not files:
            return await ctx.reply("📁 No local audio files found in `./music`, `./songs`, or `./audio` folders.")

        player = get_guild_player(self.bot, ctx.guild.id)
        player.text_channel = ctx.channel

        new_songs = []
        for meta in files:
            song_data = {
                "title": meta.get("title", os.path.splitext(os.path.basename(meta["path"]))[0]),
                "artist": meta.get("artist", "Local Music"),
                "duration": meta.get("duration", 0),
                "url": "",
                "webpage_url": "",
                "thumbnail": None,
                "is_local": True,
                "local_path": meta["path"]
            }
            new_songs.append(Song(song_data, ctx.author))

        player.queue.extend(new_songs)
        music_cog = self.bot.get_cog("Music")

        if not vc.is_playing() and not vc.is_paused():
            if music_cog:
                await music_cog.play_next(ctx.guild)
            await ctx.reply(f"🎶 Queued and started playing **{len(new_songs)} local tracks**!")
        else:
            if music_cog:
                await music_cog.update_dashboard(ctx.guild)
            await ctx.reply(f"📥 Added **{len(new_songs)} local tracks** to the queue!")

    @commands.hybrid_command(name="library", aliases=["locallist", "localmusic"], description="List all songs available in the local music library.")
    async def library(self, ctx: commands.Context):
        files = get_local_music_files()
        if not files:
            return await ctx.reply("📁 No local audio files found. Place songs inside a `./music` folder!")

        embed = discord.Embed(title=f"📁 Local Music Library ({len(files)} Tracks)", color=0x3498DB)
        lines = []
        for idx, f in enumerate(files[:15], start=1):
            m, s = divmod(f.get("duration", 0), 60)
            dur_str = f"{m}:{s:02d}" if f.get("duration", 0) > 0 else "--:--"
            lines.append(f"`{idx:02d}.` **{f['title']}** - *{f['artist']}* `[{dur_str}]`")

        embed.description = "\n".join(lines)
        if len(files) > 15:
            embed.set_footer(text=f"... and {len(files) - 15} more tracks in folder")
        else:
            embed.set_footer(text="Use !shuffleall to shuffle & play all local tracks!")

        await ctx.reply(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Library(bot))

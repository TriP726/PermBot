import os
import aiohttp
import discord
from typing import Optional, Dict, Any, List
import mutagen

AUDIO_FILTERS: Dict[str, str] = {
    "none": "",
    "bassboost": "bass=g=10,dynaudnorm=f=150",
    "nightcore": "asetrate=48000*1.25,aresample=48000,atempo=1.05",
    "vaporwave": "asetrate=48000*0.8,aresample=48000,atempo=0.9",
    "8d": "apulsator=hz=0.125",
    "treble": "treble=g=8",
    "pop": "equalizer=f=1000:t=q:w=1:g=3",
    "soft": "lowpass=f=3000",
    "echo": "aecho=0.8:0.88:60:0.4",
    "karaoke": "stereotools=mlev=0.0:slev=1.0"
}
EQ_FILTERS = AUDIO_FILTERS

SUPPORTED_AUDIO_EXTENSIONS = ('.mp3', '.wav', '.ogg', '.m4a', '.flac')
SUPPORTED_VIDEO_EXTENSIONS = ('.mp4', '.mov', '.mkv', '.webm', '.avi', '.wmv', '.flv')
SUPPORTED_MEDIA_EXTENSIONS = SUPPORTED_AUDIO_EXTENSIONS + SUPPORTED_VIDEO_EXTENSIONS

def get_file_metadata(file_path: str) -> Dict[str, Any]:
    metadata = {
        "title": os.path.splitext(os.path.basename(file_path))[0],
        "duration": 0,
        "artist": "Local Audio"
    }
    try:
        audio = mutagen.File(file_path)
        if audio and audio.info and hasattr(audio.info, 'length'):
            metadata["duration"] = int(audio.info.length)
        if audio and audio.tags:
            if 'TIT2' in audio.tags:
                metadata["title"] = str(audio.tags['TIT2'])
            elif 'title' in audio.tags:
                metadata["title"] = str(audio.tags['title'][0])
            if 'TPE1' in audio.tags:
                metadata["artist"] = str(audio.tags['TPE1'])
            elif 'artist' in audio.tags:
                metadata["artist"] = str(audio.tags['artist'][0])
    except Exception:
        pass
    return metadata

get_local_file_metadata = get_file_metadata

def scan_local_library(base_path: str = "music") -> List[Dict[str, Any]]:
    tracks = []
    if not os.path.exists(base_path):
        os.makedirs(base_path, exist_ok=True)
        return tracks

    for root, _, files in os.walk(base_path):
        for file in files:
            if file.lower().endswith(SUPPORTED_MEDIA_EXTENSIONS):
                full_path = os.path.abspath(os.path.join(root, file))
                meta = get_file_metadata(full_path)
                folder_name = os.path.basename(root)
                tracks.append({
                    "title": meta["title"],
                    "artist": meta["artist"],
                    "duration": meta["duration"],
                    "path": full_path,
                    "folder": folder_name if root != base_path else "Root"
                })
    return tracks

scan_library = scan_local_library

async def download_discord_attachment(attachment: discord.Attachment, destination_folder: str = "music/uploads") -> Optional[str]:
    os.makedirs(destination_folder, exist_ok=True)
    clean_filename = "".join(c for c in attachment.filename if c.isalnum() or c in "._- ")
    file_path = os.path.abspath(os.path.join(destination_folder, clean_filename))
    
    async with aiohttp.ClientSession() as session:
        async with session.get(attachment.url) as response:
            if response.status == 200:
                with open(file_path, "wb") as f:
                    f.write(await response.read())
                return file_path
    return None

def create_audio_source(source_url_or_path: str, filter_name: Optional[str] = None, seek_seconds: int = 0) -> discord.FFmpegPCMAudio:
    before_args = []
    
    # -reconnect MUST ONLY be used on remote URLs, NEVER on local filesystem files
    if source_url_or_path.startswith(("http://", "https://")):
        before_args.append("-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5")
    
    if seek_seconds > 0:
        before_args.append(f"-ss {seek_seconds}")
        
    before_opts = " ".join(before_args) if before_args else None

    opts = "-vn"
    if filter_name and filter_name.lower() in AUDIO_FILTERS and AUDIO_FILTERS[filter_name.lower()]:
        opts += f' -af "{AUDIO_FILTERS[filter_name.lower()]}"'

    return discord.FFmpegPCMAudio(
        source_url_or_path,
        before_options=before_opts,
        options=opts
    )

async def extract_tracks(query: str) -> List[Dict[str, Any]]:
    tracks = []
    local_tracks = scan_local_library()
    query_lower = query.lower()
    for t in local_tracks:
        if query_lower in t["title"].lower() or query_lower in t["folder"].lower():
            tracks.append(t)
    return tracks
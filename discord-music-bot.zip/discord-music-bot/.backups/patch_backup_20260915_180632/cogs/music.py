import os
import random
import time
import asyncio
from typing import Optional, Dict
import discord
from discord.ext import commands
from discord import app_commands

from cogs.player_state import Track, GuildPlayer, guild_players, get_guild_player
from utils.helpers import format_duration, parse_duration, load_json, save_json
from utils.audio import scan_local_library, download_discord_attachment, create_audio_source, SUPPORTED_MEDIA_EXTENSIONS

MUSIC_SETTINGS_FILE = "data/music_settings.json"

class Music(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.settings = load_json(MUSIC_SETTINGS_FILE, default={"247": {}})
        self.inactivity_task = self.bot.loop.create_task(self.inactivity_watcher())

    def cog_unload(self):
        if self.inactivity_task:
            self.inactivity_task.cancel()

    def get_player(self, guild: discord.Guild) -> GuildPlayer:
        return get_guild_player(guild.id, bot=self.bot, music_cog=self)

    async def inactivity_watcher(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            await asyncio.sleep(15)
            for guild_id, player in list(guild_players.items()):
                guild = self.bot.get_guild(guild_id)
                if not guild or not player.voice_client or not player.voice_client.is_connected():
                    continue

                if self.settings.get("247", {}).get(str(guild_id), False):
                    continue

                members = [m for m in player.voice_client.channel.members if not m.bot]
                if len(members) == 0:
                    await asyncio.sleep(60)
                    members = [m for m in player.voice_client.channel.members if not m.bot]
                    if len(members) == 0 and player.voice_client and player.voice_client.is_connected():
                        await player.voice_client.disconnect()
                        player.is_playing = False
                        player.current_track = None
                        await player.update_ui()
                        continue

                if not player.voice_client.is_playing() and not player.voice_client.is_paused() and not player.queue:
                    await asyncio.sleep(120)
                    if not player.voice_client.is_playing() and not player.queue and player.voice_client.is_connected():
                        await player.voice_client.disconnect()
                        player.is_playing = False
                        player.current_track = None
                        await player.update_ui()

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        player = guild_players.get(message.guild.id)
        if player and player.bound_channel and player.bound_channel.id == message.channel.id:
            if player.current_track and player.player_message and message.id != player.player_message.id:
                player.schedule_sticky_refresh()

    async def play_next_wrapper(self, guild_id: int, error: Optional[Exception] = None):
        player = guild_players.get(guild_id)
        if not player or player.is_seeking:
            return

        now = time.time()
        if now - player.last_error_time < 2.0:
            player.consecutive_errors += 1
        else:
            player.consecutive_errors = 0
        player.last_error_time = now

        if player.consecutive_errors > 4:
            if player.bound_channel:
                await player.bound_channel.send("⚠️ Consecutive playback errors encountered. Pausing queue.")
            player.is_playing = False
            player.current_track = None
            await player.update_ui()
            return

        await asyncio.sleep(0.1)
        await self.play_next(guild_id)

    async def play_next(self, guild_id: int):
        player = guild_players.get(guild_id)
        if not player or not player.voice_client or not player.voice_client.is_connected():
            return

        if player.loop_mode == "track" and player.current_track and not player.skip_requested:
            track_to_play = player.current_track
        elif player.queue:
            if player.loop_mode == "queue" and player.current_track and not player.skip_requested:
                player.queue.append(player.current_track)
            track_to_play = player.queue.pop(0)
        else:
            player.is_playing = False
            player.current_track = None
            player.skip_requested = False
            await player.update_ui()
            return

        player.skip_requested = False

        if not track_to_play.source_url.startswith(("http://", "https://")):
            if not os.path.exists(track_to_play.source_url):
                print(f"[Music Error]: File not found: {track_to_play.source_url}")
                await self.play_next_wrapper(guild_id)
                return

        player.current_track = track_to_play
        player.track_start_time = time.time()
        player.current_position = 0

        try:
            source = create_audio_source(track_to_play.source_url, filter_name=player.current_filter)

            def after_playback(err):
                asyncio.run_coroutine_threadsafe(self.play_next_wrapper(guild_id, err), self.bot.loop)

            if player.voice_client.is_playing() or player.voice_client.is_paused():
                player.voice_client.stop()

            player.voice_client.play(source, after=after_playback)
            player.is_playing = True
            await player.update_ui(force_repost=True)
        except Exception as e:
            print(f"[Music Playback Error]: {e}")
            await self.play_next_wrapper(guild_id, e)

    @commands.hybrid_command(name="play", description="Play a local track, uploaded file, or query.")
    @app_commands.describe(query="Name of track or folder to play")
    async def play(self, ctx: commands.Context, *, query: Optional[str] = None):
        if not ctx.author.voice or not ctx.author.voice.channel:
            return await ctx.send("❌ You must be in a voice channel to play music.", ephemeral=True)

        player = self.get_player(ctx.guild)
        player.bound_channel = ctx.channel

        if not player.voice_client or not player.voice_client.is_connected():
            player.voice_client = await ctx.author.voice.channel.connect()
        elif player.voice_client.channel.id != ctx.author.voice.channel.id:
            await player.voice_client.move_to(ctx.author.voice.channel)

        if ctx.message.attachments:
            att = ctx.message.attachments[0]
            if att.filename.lower().endswith(SUPPORTED_MEDIA_EXTENSIONS):
                if att.size > 50 * 1024 * 1024:
                    return await ctx.send("❌ File size exceeds 50MB limit.", ephemeral=True)
                path = await download_discord_attachment(att)
                if path:
                    track = Track(title=att.filename, source_url=path, requester=ctx.author)
                    player.queue.append(track)
                    await ctx.send(f"📥 Added attachment **{att.filename}** to the queue.")
                    if not player.voice_client.is_playing() and not player.voice_client.is_paused():
                        await self.play_next(ctx.guild.id)
                    else:
                        await player.update_ui()
                    return

        if not query:
            return await ctx.send("❌ Please provide a song name, folder name, or attach a media file.", ephemeral=True)

        tracks = scan_local_library()
        query_lower = query.lower()
        matched = [t for t in tracks if query_lower in t["title"].lower() or query_lower in t["folder"].lower()]

        if not matched:
            return await ctx.send(f"❌ No tracks matching `{query}` were found in local library.", ephemeral=True)

        for m in matched:
            t = Track(title=m["title"], source_url=m["path"], duration=m["duration"], requester=ctx.author)
            player.queue.append(t)

        if len(matched) == 1:
            await ctx.send(f"🎶 Added **{matched[0]['title']}** to the queue.")
        else:
            await ctx.send(f"📁 Added **{len(matched)}** tracks matching `{query}` to the queue.")

        if not player.voice_client.is_playing() and not player.voice_client.is_paused():
            await self.play_next(ctx.guild.id)
        else:
            await player.update_ui()

    @commands.hybrid_command(name="playnext", description="Insert a track to play next immediately after the current song.")
    @app_commands.describe(query="Name of track or folder to play next")
    async def playnext(self, ctx: commands.Context, *, query: Optional[str] = None):
        if not ctx.author.voice or not ctx.author.voice.channel:
            return await ctx.send("❌ You must be in a voice channel to play music.", ephemeral=True)

        player = self.get_player(ctx.guild)
        player.bound_channel = ctx.channel

        if not player.voice_client or not player.voice_client.is_connected():
            player.voice_client = await ctx.author.voice.channel.connect()

        if ctx.message.attachments:
            att = ctx.message.attachments[0]
            if att.filename.lower().endswith(SUPPORTED_MEDIA_EXTENSIONS):
                path = await download_discord_attachment(att)
                if path:
                    track = Track(title=att.filename, source_url=path, requester=ctx.author)
                    player.queue.insert(0, track)
                    await ctx.send(f"📥 Inserted **{att.filename}** as the next track.")
                    if not player.voice_client.is_playing() and not player.voice_client.is_paused():
                        await self.play_next(ctx.guild.id)
                    else:
                        await player.update_ui()
                    return

        if not query:
            return await ctx.send("❌ Please provide a song name or attach a media file.", ephemeral=True)

        tracks = scan_local_library()
        query_lower = query.lower()
        matched = [t for t in tracks if query_lower in t["title"].lower() or query_lower in t["folder"].lower()]

        if not matched:
            return await ctx.send(f"❌ No tracks matching `{query}` were found.", ephemeral=True)

        for m in reversed(matched):
            player.queue.insert(0, Track(title=m["title"], source_url=m["path"], duration=m["duration"], requester=ctx.author))

        await ctx.send(f"🎶 Inserted **{matched[0]['title']}** to play next.")
        if not player.voice_client.is_playing() and not player.voice_client.is_paused():
            await self.play_next(ctx.guild.id)
        else:
            await player.update_ui()

    @commands.hybrid_command(name="skip", description="Skip the currently playing track.")
    async def skip(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if not player.voice_client or not (player.voice_client.is_playing() or player.voice_client.is_paused()):
            return await ctx.send("❌ Nothing is currently playing.", ephemeral=True)

        player.skip_requested = True
        player.voice_client.stop()
        await ctx.send("⏭️ Skipped current track.")

    @commands.hybrid_command(name="pause", description="Pause the currently playing track.")
    async def pause(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if not player.voice_client or not player.voice_client.is_playing():
            return await ctx.send("❌ Nothing is currently playing to pause.", ephemeral=True)

        player.voice_client.pause()
        player.current_position = player.get_position()
        await player.update_ui()
        await ctx.send("⏸️ Playback paused.")

    @commands.hybrid_command(name="resume", description="Resume playback of a paused track.")
    async def resume(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if not player.voice_client or not player.voice_client.is_paused():
            return await ctx.send("❌ Playback is not paused.", ephemeral=True)

        player.track_start_time = time.time() - player.current_position
        player.voice_client.resume()
        await player.update_ui()
        await ctx.send("▶️ Playback resumed.")

    @commands.hybrid_command(name="stop", description="Stop music and clear the queue.")
    async def stop(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        player.queue.clear()
        player.current_track = None
        if player.voice_client and player.voice_client.is_connected():
            player.voice_client.stop()
            await player.voice_client.disconnect()
        await player.update_ui()
        await ctx.send("⏹️ Playback stopped and queue cleared.")

    @commands.hybrid_command(name="queue", description="Display the current music queue.")
    async def queue(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if not player.queue and not player.current_track:
            return await ctx.send("📂 Queue is currently empty.", ephemeral=True)

        lines = [f"**Now Playing**: {player.current_track.title} (`{format_duration(player.get_position())}` / `{format_duration(player.current_track.duration)}`)"]
        for i, t in enumerate(player.queue[:15], 1):
            lines.append(f"`{i}.` **{t.title}** ({format_duration(t.duration)})")

        if len(player.queue) > 15:
            lines.append(f"\n*...and {len(player.queue) - 15} more track(s)*")

        embed = discord.Embed(title="📑 Music Queue", description="\n".join(lines), color=discord.Color.purple())
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="nowplaying", aliases=["np"], description="Show details of the current track.")
    async def nowplaying(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        if not player.current_track:
            return await ctx.send("❌ Nothing is currently playing.", ephemeral=True)
        embed = player.build_player_embed()
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="seek", description="Seek to a specific timestamp (e.g. 1:30 or 90s).")
    @app_commands.describe(timestamp="Timestamp (e.g., 1:45 or 105)")
    async def seek(self, ctx: commands.Context, timestamp: str):
        player = self.get_player(ctx.guild)
        if not player.current_track or not player.voice_client:
            return await ctx.send("❌ Nothing is currently playing.", ephemeral=True)

        seconds = parse_duration(timestamp)
        if seconds is None or seconds < 0:
            return await ctx.send("❌ Invalid timestamp format. Use `MM:SS` or seconds.", ephemeral=True)

        await ctx.send(f"⏩ Seeking to `{format_duration(seconds)}`...")
        await player.seek(seconds)

    @commands.hybrid_command(name="shuffle", description="Shuffle current queue, entire library, or folder.")
    @app_commands.describe(scope="Scope: leave empty for queue, 'all' for library, or folder name")
    async def shuffle(self, ctx: commands.Context, scope: Optional[str] = None):
        player = self.get_player(ctx.guild)
        player.bound_channel = ctx.channel

        if not scope:
            if len(player.queue) < 2:
                return await ctx.send("❌ Queue has less than 2 tracks to shuffle.", ephemeral=True)
            random.shuffle(player.queue)
            await ctx.send("🔀 Active queue has been shuffled.")
            return await player.update_ui()

        tracks = scan_local_library()
        if scope.lower() == "all":
            selected = list(tracks)
        else:
            selected = [t for t in tracks if scope.lower() in t["folder"].lower()]

        if not selected:
            return await ctx.send(f"❌ No tracks found for scope `{scope}`.", ephemeral=True)

        random.shuffle(selected)
        for m in selected:
            player.queue.append(Track(title=m["title"], source_url=m["path"], duration=m["duration"], requester=ctx.author))

        await ctx.send(f"🔀 Shuffled and queued **{len(selected)}** tracks.")
        
        if not player.voice_client or not player.voice_client.is_connected():
            if ctx.author.voice and ctx.author.voice.channel:
                player.voice_client = await ctx.author.voice.channel.connect()
                await self.play_next(ctx.guild.id)
            else:
                return await ctx.send("⚠️ You must be in a voice channel to start playback.", ephemeral=True)
        elif not player.voice_client.is_playing() and not player.voice_client.is_paused():
            await self.play_next(ctx.guild.id)
        else:
            await player.update_ui()

    @commands.hybrid_command(name="loop", description="Set loop mode (off, track, queue).")
    @app_commands.describe(mode="Loop mode: 'off', 'track', or 'queue'")
    async def loop(self, ctx: commands.Context, mode: Optional[str] = None):
        player = self.get_player(ctx.guild)
        if not mode:
            modes = ["off", "track", "queue"]
            idx = (modes.index(player.loop_mode) + 1) % len(modes)
            player.loop_mode = modes[idx]
        elif mode.lower() in ["off", "track", "queue"]:
            player.loop_mode = mode.lower()
        else:
            return await ctx.send("❌ Invalid mode. Choose from `off`, `track`, or `queue`.", ephemeral=True)

        await player.update_ui()
        await ctx.send(f"🔁 Loop mode set to **{player.loop_mode}**.")

    @commands.hybrid_command(name="clear", description="Clear all tracks in the waiting queue.")
    async def clear(self, ctx: commands.Context):
        player = self.get_player(ctx.guild)
        count = len(player.queue)
        player.queue.clear()
        await player.update_ui()
        await ctx.send(f"🗑️ Cleared **{count}** tracks from the queue.")

    @commands.hybrid_command(name="remove", description="Remove a track by its position number in queue.")
    @app_commands.describe(index="Position number in queue")
    async def remove(self, ctx: commands.Context, index: int):
        player = self.get_player(ctx.guild)
        if index < 1 or index > len(player.queue):
            return await ctx.send("❌ Invalid position number.", ephemeral=True)
        removed = player.queue.pop(index - 1)
        await player.update_ui()
        await ctx.send(f"🗑️ Removed **{removed.title}** from the queue.")

    @commands.hybrid_command(name="247", description="Toggle 24/7 mode in voice channel.")
    @commands.has_permissions(administrator=True)
    async def toggle_247(self, ctx: commands.Context):
        g_id = str(ctx.guild.id)
        if "247" not in self.settings:
            self.settings["247"] = {}
        curr = self.settings["247"].get(g_id, False)
        self.settings["247"][g_id] = not curr
        save_json(MUSIC_SETTINGS_FILE, self.settings)
        state = "enabled" if not curr else "disabled"
        await ctx.send(f"🔒 24/7 Voice mode is now **{state}**.")

async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
import asyncio
import time
from typing import Optional, List, Dict, Any
import discord
from discord.ui import View, Button, Select

from utils.helpers import format_duration, create_progress_bar
from utils.audio import AUDIO_FILTERS, create_audio_source

guild_players: Dict[int, "GuildPlayer"] = {}

def get_guild_player(guild_id: int, bot: Optional[discord.Client] = None, music_cog: Optional[Any] = None) -> "GuildPlayer":
    if guild_id not in guild_players:
        guild_players[guild_id] = GuildPlayer(guild_id=guild_id, bot=bot, music_cog=music_cog)
    return guild_players[guild_id]

class Track:
    def __init__(self, title: str, source_url: str, duration: int = 0, is_stream: bool = False, requester: Optional[discord.Member] = None):
        self.title: str = title
        self.source_url: str = source_url
        self.duration: int = int(duration) if duration else 0
        self.is_stream: bool = is_stream
        self.requester: Optional[discord.Member] = requester

    @property
    def source_path(self) -> str:
        return self.source_url

class GuildPlayer:
    def __init__(self, guild_id: int, bot: Optional[discord.Client] = None, music_cog: Optional[Any] = None):
        self.guild_id: int = guild_id
        self.bot: Optional[discord.Client] = bot
        self.music_cog: Optional[Any] = music_cog
        self.queue: List[Track] = []
        self.current_track: Optional[Track] = None
        self.voice_client: Optional[discord.VoiceClient] = None
        self.bound_channel: Optional[discord.TextChannel] = None
        self.player_message: Optional[discord.Message] = None
        
        self.is_playing: bool = False
        self.is_seeking: bool = False
        self.skip_requested: bool = False
        self.loop_mode: str = "off"  # "off", "track", "queue"
        self.current_filter: str = "none"
        self.volume: float = 1.0
        
        self.track_start_time: float = 0.0
        self.current_position: int = 0
        
        self.consecutive_errors: int = 0
        self.last_error_time: float = 0.0
        
        self.ui_lock = asyncio.Lock()
        self._sticky_task: Optional[asyncio.Task] = None

    def get_position(self) -> int:
        if not self.is_playing or self.track_start_time == 0:
            return self.current_position
        if self.voice_client and self.voice_client.is_paused():
            return self.current_position
        return max(0, int(time.time() - self.track_start_time))

    def build_player_embed(self) -> discord.Embed:
        if not self.current_track:
            embed = discord.Embed(
                title="🎵 PermBot Music Player",
                description="No music currently playing. Use `/play` or `!play` to start listening!",
                color=discord.Color.dark_grey()
            )
            embed.set_footer(text="PermBot Music System • Ready")
            return embed

        cur_pos = self.get_position()
        dur = self.current_track.duration
        
        embed = discord.Embed(
            title="🎶 Now Playing",
            description=f"**[{self.current_track.title}]({self.current_track.source_url if self.current_track.source_url.startswith('http') else 'https://discord.com'})**",
            color=discord.Color.purple()
        )
        
        if dur > 0 and not self.current_track.is_stream:
            progress_bar = create_progress_bar(cur_pos, dur, length=16)
            embed.add_field(
                name="Progress",
                value=f"`{format_duration(cur_pos)}` {progress_bar} `{format_duration(dur)}`",
                inline=False
            )
        else:
            embed.add_field(name="Progress", value=f"`🔴 LIVE / Direct Audio` (`{format_duration(cur_pos)}` elapsed)", inline=False)

        status_str = "▶️ Playing" if (self.voice_client and self.voice_client.is_playing()) else "⏸️ Paused"
        loop_str = "🔂 Single" if self.loop_mode == "track" else ("🔁 Queue" if self.loop_mode == "queue" else "Off")
        filter_str = self.current_filter.capitalize() if self.current_filter != "none" else "None"
        req_str = self.current_track.requester.mention if self.current_track.requester else "Unknown"

        embed.add_field(name="Status", value=status_str, inline=True)
        embed.add_field(name="Loop", value=loop_str, inline=True)
        embed.add_field(name="DSP Filter", value=filter_str, inline=True)
        embed.add_field(name="Queue", value=f"{len(self.queue)} track(s)", inline=True)
        embed.add_field(name="Volume", value=f"{int(self.volume * 100)}%", inline=True)
        embed.add_field(name="Requested By", value=req_str, inline=True)

        embed.set_footer(text="Row 1: Playback | Row 2: Controls | Row 3: Seek | Row 4: Filters")
        return embed

    async def update_ui(self, force_repost: bool = False):
        if not self.bound_channel:
            return

        async with self.ui_lock:
            try:
                embed = self.build_player_embed()
                view = PlayerView(self) if self.current_track else None
                
                should_repost = force_repost
                if self.player_message and not should_repost:
                    try:
                        last_msg = None
                        async for m in self.bound_channel.history(limit=1):
                            last_msg = m
                        if last_msg and last_msg.id != self.player_message.id:
                            should_repost = True
                    except Exception:
                        should_repost = False

                if should_repost and self.player_message:
                    try:
                        await self.player_message.delete()
                    except Exception:
                        pass
                    self.player_message = None

                if self.player_message:
                    try:
                        await self.player_message.edit(embed=embed, view=view)
                    except discord.NotFound:
                        self.player_message = await self.bound_channel.send(embed=embed, view=view)
                else:
                    self.player_message = await self.bound_channel.send(embed=embed, view=view)
            except Exception as e:
                print(f"[Player UI Update Error - Guild {self.guild_id}]: {e}")

    def schedule_sticky_refresh(self):
        if self._sticky_task and not self._sticky_task.done():
            self._sticky_task.cancel()
        self._sticky_task = asyncio.create_task(self._debounced_sticky_refresh())

    async def _debounced_sticky_refresh(self):
        await asyncio.sleep(1.5)
        if self.current_track and self.bound_channel:
            await self.update_ui(force_repost=True)

    async def seek(self, target_seconds: int) -> bool:
        if not self.voice_client or not self.current_track:
            return False

        self.is_seeking = True
        self.current_position = target_seconds
        self.track_start_time = time.time() - target_seconds

        try:
            source = create_audio_source(
                self.current_track.source_url,
                filter_name=self.current_filter,
                seek_seconds=target_seconds
            )
            
            if self.voice_client.is_playing() or self.voice_client.is_paused():
                self.voice_client.stop()
                
            await asyncio.sleep(0.15)
            
            def after_playback(err):
                if self.music_cog:
                    loop = self.bot.loop if self.bot else asyncio.get_event_loop()
                    asyncio.run_coroutine_threadsafe(
                        self.music_cog.play_next_wrapper(self.guild_id, err),
                        loop
                    )

            self.voice_client.play(source, after=after_playback)
            self.is_playing = True
        except Exception as e:
            print(f"[Seek Play Error - Guild {self.guild_id}]: {e}")
            return False
        finally:
            self.is_seeking = False
            await self.update_ui()
        return True

class SeekSelect(Select):
    def __init__(self, player: GuildPlayer):
        self.player = player
        options: List[discord.SelectOption] = []
        dur = player.current_track.duration if (player.current_track and player.current_track.duration) else 0
        current_pos = player.get_position()

        if dur > 10:
            step_count = min(15, max(5, int(dur // 20)))
            step = max(5, int(dur / (step_count + 1)))
            seen_values = set()
            for s in range(step, int(dur) - 3, step):
                if s not in seen_values and len(options) < 25:
                    seen_values.add(s)
                    options.append(
                        discord.SelectOption(
                            label=f"Seek to {format_duration(s)}",
                            value=str(s),
                            description=f"Jump playback to {format_duration(s)}",
                            emoji="⏩"
                        )
                    )
        else:
            fallback_intervals = [15, 30, 60, 120, 180, 300, 600, 900, 1200, 1800]
            for s in fallback_intervals:
                options.append(
                    discord.SelectOption(
                        label=f"Jump to {format_duration(s)}",
                        value=str(s),
                        description=f"Seek into audio at {format_duration(s)}",
                        emoji="⏩"
                    )
                )

        if not options:
            options.append(discord.SelectOption(label="Seek Unavailable", value="0"))
            super().__init__(placeholder="⏩ Jump to timestamp...", min_values=1, max_values=1, options=options, row=2, disabled=True)
        else:
            super().__init__(placeholder=f"⏩ Jump to timestamp... (Current: {format_duration(current_pos)})", min_values=1, max_values=1, options=options[:25], row=2, disabled=False)

    async def callback(self, interaction: discord.Interaction):
        if not self.player.voice_client or not self.player.current_track:
            return await interaction.response.send_message("❌ Nothing is currently playing.", ephemeral=True)
        target = int(self.values[0])
        await interaction.response.defer()
        await self.player.seek(target)

class FilterSelect(Select):
    def __init__(self, player: GuildPlayer):
        self.player = player
        options = []
        for name in AUDIO_FILTERS.keys():
            options.append(
                discord.SelectOption(
                    label=name.capitalize() if name != "none" else "Normal (No DSP)",
                    value=name,
                    description=f"Apply {name} equalization filter",
                    default=(name == player.current_filter),
                    emoji="🎛️"
                )
            )
        super().__init__(placeholder="🎛️ Select Equalizer / DSP Preset...", min_values=1, max_values=1, options=options, row=3)

    async def callback(self, interaction: discord.Interaction):
        chosen_filter = self.values[0]
        self.player.current_filter = chosen_filter
        await interaction.response.defer()
        cur_pos = self.player.get_position()
        await self.player.seek(cur_pos)

class PlayerView(View):
    def __init__(self, player: GuildPlayer):
        super().__init__(timeout=None)
        self.player = player
        
        # Row 0: Playback controls
        self.prev_button = Button(emoji="⏮️", style=discord.ButtonStyle.secondary, row=0, custom_id="permbot:prev")
        self.prev_button.callback = self.on_prev
        self.add_item(self.prev_button)

        is_paused = player.voice_client.is_paused() if player.voice_client else False
        self.play_pause_button = Button(
            emoji="▶️" if is_paused else "⏸️",
            style=discord.ButtonStyle.primary if not is_paused else discord.ButtonStyle.success,
            row=0,
            custom_id="permbot:playpause"
        )
        self.play_pause_button.callback = self.on_play_pause
        self.add_item(self.play_pause_button)

        self.skip_button = Button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0, custom_id="permbot:skip")
        self.skip_button.callback = self.on_skip
        self.add_item(self.skip_button)

        self.stop_button = Button(emoji="⏹️", style=discord.ButtonStyle.danger, row=0, custom_id="permbot:stop")
        self.stop_button.callback = self.on_stop
        self.add_item(self.stop_button)

        # Row 1: Tools & Toggles
        self.shuffle_button = Button(emoji="🔀", style=discord.ButtonStyle.secondary, row=1, custom_id="permbot:shuffle")
        self.shuffle_button.callback = self.on_shuffle
        self.add_item(self.shuffle_button)

        loop_styles = {
            "off": discord.ButtonStyle.secondary,
            "track": discord.ButtonStyle.primary,
            "queue": discord.ButtonStyle.success
        }
        self.loop_button = Button(
            emoji="🔂" if player.loop_mode == "track" else "🔁",
            style=loop_styles.get(player.loop_mode, discord.ButtonStyle.secondary),
            row=1,
            custom_id="permbot:loop"
        )
        self.loop_button.callback = self.on_loop
        self.add_item(self.loop_button)

        self.queue_button = Button(emoji="📑", label="Queue", style=discord.ButtonStyle.secondary, row=1, custom_id="permbot:queue")
        self.queue_button.callback = self.on_queue
        self.add_item(self.queue_button)

        self.lyrics_button = Button(emoji="📜", label="Lyrics", style=discord.ButtonStyle.secondary, row=1, custom_id="permbot:lyrics")
        self.lyrics_button.callback = self.on_lyrics
        self.add_item(self.lyrics_button)

        # Row 2 & Row 3: Dropdowns
        self.add_item(SeekSelect(player))
        self.add_item(FilterSelect(player))

    async def on_prev(self, interaction: discord.Interaction):
        await interaction.response.defer()
        await self.player.seek(0)

    async def on_play_pause(self, interaction: discord.Interaction):
        if not self.player.voice_client:
            return await interaction.response.send_message("❌ Bot is not connected to voice.", ephemeral=True)
        if self.player.voice_client.is_playing():
            self.player.voice_client.pause()
            self.player.current_position = self.player.get_position()
        elif self.player.voice_client.is_paused():
            self.player.track_start_time = time.time() - self.player.current_position
            self.player.voice_client.resume()
        await interaction.response.defer()
        await self.player.update_ui()

    async def on_skip(self, interaction: discord.Interaction):
        if not self.player.voice_client:
            return await interaction.response.send_message("❌ Bot is not connected to voice.", ephemeral=True)
        await interaction.response.defer()
        self.player.skip_requested = True
        if self.player.voice_client.is_playing() or self.player.voice_client.is_paused():
            self.player.voice_client.stop()

    async def on_stop(self, interaction: discord.Interaction):
        self.player.queue.clear()
        self.player.current_track = None
        if self.player.voice_client:
            self.player.voice_client.stop()
            await self.player.voice_client.disconnect()
        await interaction.response.defer()
        await self.player.update_ui()

    async def on_shuffle(self, interaction: discord.Interaction):
        import random
        if len(self.player.queue) < 2:
            return await interaction.response.send_message("❌ Need at least 2 tracks in queue to shuffle.", ephemeral=True)
        random.shuffle(self.player.queue)
        await interaction.response.send_message("🔀 Queue shuffled!", ephemeral=True)
        await self.player.update_ui()

    async def on_loop(self, interaction: discord.Interaction):
        modes = ["off", "track", "queue"]
        idx = (modes.index(self.player.loop_mode) + 1) % len(modes)
        self.player.loop_mode = modes[idx]
        await interaction.response.defer()
        await self.player.update_ui()

    async def on_queue(self, interaction: discord.Interaction):
        if not self.player.queue and not self.player.current_track:
            return await interaction.response.send_message("Queue is currently empty.", ephemeral=True)
        lines = [f"**Now Playing**: {self.player.current_track.title}"]
        for i, t in enumerate(self.player.queue[:10], 1):
            lines.append(f"`{i}.` {t.title} ({format_duration(t.duration)})")
        if len(self.player.queue) > 10:
            lines.append(f"*...and {len(self.player.queue) - 10} more tracks*")
        embed = discord.Embed(title="📑 Current Queue", description="\n".join(lines), color=discord.Color.purple())
        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def on_lyrics(self, interaction: discord.Interaction):
        if not self.player.current_track:
            return await interaction.response.send_message("❌ Nothing is playing.", ephemeral=True)
        lyrics_cog = self.player.bot.get_cog("Lyrics") if self.player.bot else None
        if lyrics_cog and hasattr(lyrics_cog, 'fetch_lyrics'):
            await interaction.response.defer(ephemeral=True)
            res = await lyrics_cog.fetch_lyrics(self.player.current_track.title)
            if res:
                embed = discord.Embed(title=f"📜 Lyrics: {self.player.current_track.title}", description=res[:4000], color=discord.Color.purple())
                return await interaction.followup.send(embed=embed, ephemeral=True)
        await interaction.response.send_message(f"❌ Lyrics for `{self.player.current_track.title}` could not be found.", ephemeral=True)

async def setup(bot):
    pass
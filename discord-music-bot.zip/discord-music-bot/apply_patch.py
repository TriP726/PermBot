"""
apply_patch.py - PermBot Fast Multi-File Patcher
Reads 'patch.json', creates automatic backups, and writes all updated files.
"""

import os
import sys
import json
import shutil
from datetime import datetime

PATCH_FILE = "patch.json"
BACKUP_DIR = ".backups"

def main():
    if not os.path.exists(PATCH_FILE):
        print(f"❌ Error: '{PATCH_FILE}' not found in the current directory.")
        print(f"👉 Create '{PATCH_FILE}', paste the JSON patch block, and run this script again.")
        sys.exit(1)

    try:
        with open(PATCH_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"❌ Failed to parse '{PATCH_FILE}' as valid JSON: {e}")
        sys.exit(1)

    files = data.get("files", {})
    if not files:
        print("⚠️ No files found inside 'patch.json'. Nothing to apply.")
        sys.exit(0)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_session_dir = os.path.join(BACKUP_DIR, f"patch_backup_{timestamp}")
    os.makedirs(backup_session_dir, exist_ok=True)

    updated_count = 0
    created_count = 0

    print("=" * 55)
    print("🚀 PermBot Multi-File Patcher Running...")
    print("=" * 55)

    for rel_path, content in files.items():
        target_path = os.path.normpath(rel_path)
        target_dir = os.path.dirname(target_path)

        if target_dir:
            os.makedirs(target_dir, exist_ok=True)

        if os.path.exists(target_path):
            backup_file_path = os.path.join(backup_session_dir, target_path)
            os.makedirs(os.path.dirname(backup_file_path), exist_ok=True)
            shutil.copy2(target_path, backup_file_path)
            updated_count += 1
            status = "UPDATED"
        else:
            created_count += 1
            status = "CREATED"

        with open(target_path, "w", encoding="utf-8") as f:
            f.write(content)

        print(f"[{status}] -> {target_path}")

    # Remove patch.json to prevent accidental double-execution
    try:
        os.remove(PATCH_FILE)
    except Exception:
        pass

    print("=" * 55)
    print(f"✅ Finished! {updated_count} files updated, {created_count} files created.")
    print(f"🛡️ Backups saved to: {backup_session_dir}")
    print("=" * 55)

if __name__ == "__main__":
    main()
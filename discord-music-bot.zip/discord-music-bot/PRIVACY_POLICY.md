\# PermBot — Privacy Policy

\*\*Effective Date:\*\* September 2026



This Privacy Policy explains what data \*\*PermBot\*\* ("the bot", "we", "us") collects, why it is needed, how it is stored, and how you can exercise your data rights. 



We follow strict \*\*data minimization principles\*\*: we do not collect personal information and only store the technical identifiers required for the bot's features to function properly.



\---



\### 1. Information We Collect

When PermBot is added to a server and used by members, the following technical data may be stored:



\* \*\*Discord Server \& Channel IDs:\*\* Guild IDs, mod-log channel IDs, support ticket category IDs, and temporary voice hub IDs to route features to the correct channels.

\* \*\*User Identifiers (Discord User IDs):\*\* 

&#x20; \* Moderation records (warning logs, logged reasons, timestamps, and active timeout states).

&#x20; \* Custom playlists and favorite tracks saved via `!playlist` and `!fav`.

&#x20; \* Support ticket ownership records and closed ticket transcript metadata.

&#x20; \* Event RSVPs, waitlist queues, and live poll vote choices (stored to prevent duplicate voting).

\* \*\*Ticket Transcripts:\*\* When a support ticket is officially closed, a plain text copy (`.txt`) of that specific channel's message history is generated. This transcript is sent directly to the server's staff mod-log channel and DMed to the ticket creator for record-keeping.

\* \*\*Server Configuration Settings:\*\* Auto-mod toggle states, anti-spam thresholds, Anti-Raid sensitivity rules, minimum account age gates, and custom role panel configurations.



\---



\### 2. Information We NEVER Collect

\* \*\*Voice Communications:\*\* PermBot streams audio into voice channels. It \*\*NEVER\*\* records, captures, stores, or listens to user voice communications.

\* \*\*General Chat Logs:\*\* PermBot does not store your everyday chat messages. Messages are read ephemerally in real-time solely to execute `!` commands and run auto-mod filters (anti-spam, anti-invite, mass-mention). Once evaluated, messages are discarded from memory immediately.

\* \*\*Personal \& Financial Data:\*\* We do not collect real names, email addresses, IP addresses, payment details, or phone numbers.



\---



\### 3. How We Use Collected Data

All stored data is used strictly to power PermBot's core functionalities:

\* Maintaining warning histories and executing automatic moderation escalations (e.g., 3 warnings = timeout, 5 = kick, 7 = ban).

\* Persisting your saved playlists and favorites across bot reboots.

\* Managing dynamic voice room ownership permissions and active poll tallies.

\* Delivering disaster-recovery backup archives to server administrators.



We \*\*never\*\* 

